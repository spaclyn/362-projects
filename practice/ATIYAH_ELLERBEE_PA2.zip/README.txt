SELECTION SORT

## General Information

-   **Author Information:**
    -   Principal Coder: Atiyah B. Ellerbee
-   **Keywords:** [Relevant keywords for discoverability]

## Data/File Overview

-   **File List and Descriptions:**
    -   selectSort.cpp: [Code for selectSort.exe, the overall algroithm to see selection sort output. ]
    -   selectSort.exe: [Exe debugged from occluCalc.cpp]


-   **File Formats:** cpp, exe, txt
-   **File Relationships/Structure:** selectSort.cpp informs selectSort.exe
-   **Date of Last Update/Version:** 9/11/2025
-   **Related Data:** some help from textbook and debugging help from chatGPT

## Usage/Access Information

-   **Description:** A selection sort algorthym 
-   **Prerequisites:** ---
-   **Installation/Setup:** dependent on your system, see screen recording for execution expected on a windows machine
-   **Instructions for Use:** 
            debug and run selectSort, input the number for the array elements
	    (n), enter the selected number (n) of elements, enter and sorts
-   **Known Issues/Limitations:** 10000 is the suggested max, but you can enter over that amount without the loop booting you out to try again

## Contact Information

-   **For Questions/Support:** aellerbe@purdue.edu