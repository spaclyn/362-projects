import matplotlib.pyplot as plt
import csv

rects = []
with open("rects.csv") as f:
    reader = csv.reader(f)
    for row in reader:
        coords = list(map(float, row))
        corners = [(coords[i], coords[i+1]) for i in range(0, 8, 2)]
        rects.append(corners)

plt.figure(figsize=(6,6))

for corners in rects:
    xs = [p[0] for p in corners] + [corners[0][0]]
    ys = [p[1] for p in corners] + [corners[0][1]]
    plt.plot(xs, ys, marker="o")

# Origin
plt.plot(0, 0, "r*", markersize=15)

plt.axhline(0, color="black", linewidth=0.5)
plt.axvline(0, color="black", linewidth=0.5)
plt.gca().set_aspect("equal", adjustable="box")
plt.title("Random Rectangles and Origin")
plt.show()
